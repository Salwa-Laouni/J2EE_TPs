package org.example.bankaccountservice.enums;

public enum AccountType {
    CURRENT_ACCOUNT,SAVING_ACCOUNT
}
